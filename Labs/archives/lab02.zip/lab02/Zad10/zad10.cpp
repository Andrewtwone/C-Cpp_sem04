#include <iostream>
using namespace std;

int main()
{
  int znakA = 'A';
  char znak97 = 97;

  cout << "Znak 'A' zapisany w zmiennej typu int: " << znakA << endl;
  cout << "Wartosc 97 jako znak (char): " << znak97 << endl;

  return 0;
}
