#include "learning_app.h"

int main(int argc, char *argv[]) {
    LearningApp app;
    return app.run(argc, argv);
} 