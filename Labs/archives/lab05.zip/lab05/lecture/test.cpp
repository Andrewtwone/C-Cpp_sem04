#include <iostream>

using namespace std;

int main()
{
    char a = 116;
    int s = 's';
    cout << s << endl;
}